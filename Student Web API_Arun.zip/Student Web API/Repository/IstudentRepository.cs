﻿using Student_Web_API.Dtos;
using Student_Web_API.Entities;

namespace Student_Web_API.Repository
{
    public interface IstudentRepository
    {
        int Insertstudent(studentsAddDto model);
        List<students> GetAllStudent();
        students GetStudentbyId(int Id);
        string UpdatestudentById(int Id, studentsAddDto model);
        int DeleteStudentbyId(int Id);
    }
}
