﻿using Dapper;
using Microsoft.Data.SqlClient;
using Student_Web_API.Dtos;
using Student_Web_API.Entities;
using Student_Web_API.Helpes;
using System.Data;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace Student_Web_API.Repository
{
    public class studentRepository :IstudentRepository
    {
        private IDbConnection  Db;
        private studentDbContext _studentdbContext;
        private IConfiguration iconfiguration;
        public studentRepository(studentDbContext studentdbContext, IConfiguration iconfiguration)
        {
            _studentdbContext = studentdbContext;
            iconfiguration = iconfiguration;
            this.Db = new SqlConnection(iconfiguration.GetConnectionString("DefaultConnection"));
        }

        public int Insertstudent(studentsAddDto model)
        {
            try
            {
                var student = new DynamicParameters();
                student.Add("@Name", model.Name);
                student.Add("@Age", model.Age);
                student.Add("@Mobile_No", model.Mobile_No);
                student.Add("@Address", model.Address);
                Db.Execute("InsertStudent", student, commandType: CommandType.StoredProcedure);
                return 1;
            }
            catch (Exception e)
            {

                throw e;
            }
        }
        public List<students> GetAllStudent()
        {
            var students = Db.QueryMultiple("GetAllStudent", commandType: CommandType.StoredProcedure);
            var studentList = students.Read<students>().ToList();
            return studentList;

        }

        public students GetStudentbyId(int Id)
        {
            students student = Db.Query<students>("GetStudent", new { @Id = Id }, commandType: CommandType.StoredProcedure).FirstOrDefault();
            return student;
        }



        public string UpdatestudentById(int Id,studentsAddDto model)
        {
            try
            {
                string students = "";
                var student = new DynamicParameters();
                student.Add("@Id", Id);              
                student.Add("@Name", model.Name);
                student.Add("@Age", model.Age);
                student.Add("@Mobile_No", model.Mobile_No);
                student.Add("@Address", model.Address);
                Db.Execute("UpdatesStudent", student, commandType: CommandType.StoredProcedure); 
                return students;
            }
            catch (Exception e)
            {

                throw e;
            }
        }
        public int DeleteStudentbyId(int Id)
        {
            var std = Db.Query<students>("DeleteStudent", new { @Id = Id }, commandType: CommandType.StoredProcedure);
            return Id;
        }

    }
}
