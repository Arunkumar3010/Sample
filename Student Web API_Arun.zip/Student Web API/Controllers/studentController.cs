﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using Student_Web_API.Dtos;
using Student_Web_API.Service;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Authorization;
using Student_Web_API.Entities;

namespace Student_Web_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class studentController : ControllerBase
    {
        private readonly IstudentService _istudentService;
        private IConfiguration _iconfiguration;
        public studentController(IstudentService istudentService, IConfiguration iconfiguration)
        {
            _iconfiguration = iconfiguration;
            _istudentService = istudentService;
        }
        
        [HttpPost("InsertStudent")]
        public IActionResult InsertStudent(studentsAddDto model)
        {
            try
            {
                var responce = _istudentService.InsertStudent(model);
                return Ok(new { message = "Insert Successfully", result = responce });
            }
            catch (Exception)
            {

                return BadRequest(new { message = "something went wrong" });
            }        
        }

        [HttpGet("GetAllStudent")]
        public IActionResult GetAllStudent()
        {
            try
            {
                var response = _istudentService.GetAllStudent();
                
                    return Ok(new { message = "Students found", result = response });
            }
            catch (Exception )
            {

                return BadRequest(new { message = "Something went wrong" });
            }
        }

        [HttpGet("GetStudentbyId")]
        public IActionResult GetStudentbyId(int Id)
        {
            try
            {
                var responce = _istudentService.GetStudentbyId(Id);
                return Ok(new { message = "student found", result = responce });
            }
            catch (Exception)
            {

                return BadRequest(new { message = "something went wrong" });
            }
        }
        [HttpPut("UpdateStudentbyId")]
        public IActionResult UpdateStudentbyId(int Id,studentsAddDto model)
        {
            try
            {
                var responce = _istudentService.UpdateStudentbyId(Id, model);
           
                    return Ok(new { message = " update successfully", result = responce });
               
            }
            catch (Exception)
            {

                return BadRequest(new { message = "something went wrong" });
            }
        }

        [HttpDelete("DeleteStudentbyId")]
        public IActionResult DeleteStudentbyId(int Id)
        {
            try
            {
                var responce = _istudentService.DeleteStudentbyId(Id);
                return Ok(new { message = "Delete successfully", result = responce });
            }
            catch (Exception)
            {

                return BadRequest(new { message = "something went wrong" });
            }
        }
        [AllowAnonymous]
        [HttpPost("Login")]
        public IActionResult Login(UserLoginDto loginDto)
        {
            // Validate user credentials (this should be done using a user service)
            if (loginDto.Username == "testuser" && loginDto.Password == "password")
            {
                var tokenHandler = new JwtSecurityTokenHandler();
                var key = Encoding.UTF8.GetBytes(_iconfiguration["Jwt:Key"]);

                var tokenDescriptor = new SecurityTokenDescriptor
                {
                    Subject = new ClaimsIdentity(new[] {
                new Claim(ClaimTypes.Name, loginDto.Username)
            }),
                    Expires = DateTime.UtcNow.AddMinutes(120),
                    SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature),
                    Issuer = _iconfiguration["Jwt:Issuer"],
                    Audience = _iconfiguration["Jwt:Audience"]
                };

                var token = tokenHandler.CreateToken(tokenDescriptor);
                var tokenString = tokenHandler.WriteToken(token);

                return Ok(new { Token = tokenString });
            }

            return Unauthorized();
        }

    }
}
