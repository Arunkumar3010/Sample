﻿namespace Student_Web_API.Entities
{
    public class students
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public string Mobile_No { get; set; }
        public string Address { get; set; }

    }
}
