﻿namespace Student_Web_API.Dtos
{
    public class studentsAddDto
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public string Mobile_No { get; set; }
        public string Address { get; set; }

    }
}
