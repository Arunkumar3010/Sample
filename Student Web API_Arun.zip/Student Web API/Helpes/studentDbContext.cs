﻿using Microsoft.EntityFrameworkCore;
using Student_Web_API.Entities;

namespace Student_Web_API.Helpes
{
    public class studentDbContext : DbContext
    {
        public studentDbContext(DbContextOptions<studentDbContext> options) : base(options)
        { }
        public DbSet<students> students { get; set; }
    }
}
