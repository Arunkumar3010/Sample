﻿using Student_Web_API.Dtos;
using Student_Web_API.Entities;

namespace Student_Web_API.Service
{
    public interface IstudentService
    {
        int InsertStudent(studentsAddDto model);
        List<students> GetAllStudent();
        students GetStudentbyId(int Id);
        string UpdateStudentbyId(int Id, studentsAddDto model);
        int DeleteStudentbyId(int Id);

    }
}
