﻿using Microsoft.AspNetCore.Mvc;
using Student_Web_API.Dtos;
using Student_Web_API.Entities;
using Student_Web_API.Repository;

namespace Student_Web_API.Service
{
    public class studentService :IstudentService
    {
        private readonly IstudentRepository _studentRepository;
        public studentService(IstudentRepository studentRepository)
        {
            _studentRepository = studentRepository;
        }
        public int InsertStudent(studentsAddDto model)
        {
            var result  = _studentRepository.Insertstudent(model);
            return result;
        }
        public List<students> GetAllStudent()
        {
          return _studentRepository.GetAllStudent();
         
        }
        public students GetStudentbyId(int Id)
        {
            return _studentRepository.GetStudentbyId(Id);
        }

        public string UpdateStudentbyId(int Id, studentsAddDto model)
        {

            var result = _studentRepository.UpdatestudentById(Id, model);
            return result;
        }
        public int DeleteStudentbyId(int Id)
        {
            return _studentRepository.DeleteStudentbyId(Id);
        }
    }
}
